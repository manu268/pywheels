.. include:: globals.rst

:tocdepth: 2

.. _changes:

=========
Changelog
=========

This sections lists the biggest changes done on each release.

.. contents::
   :local:

.. include:: ../../CHANGES

