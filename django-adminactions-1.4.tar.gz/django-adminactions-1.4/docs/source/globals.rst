.. _GitHub: http://github.com/saxix/django-actions
.. _pip: http://pip.openplans.org/
.. _PyPI: http://pypi.python.org/
.. _virtualenv: http://virtualenv.openplans.org/

.. |app| replace:: django-adminactions


.. _app: https://github.com/saxix/django-adminactions
.. _django_admin: https://docs.djangoproject.com/en/dev/ref/contrib/admin/
