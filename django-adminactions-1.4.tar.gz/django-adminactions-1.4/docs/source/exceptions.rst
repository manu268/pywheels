.. include:: globals.rst
.. _exceptions:

Exceptions
==========

.. _actioninterrupted:

``ActionInterrupted``
---------------------

Exception raised to interrupt an action.

