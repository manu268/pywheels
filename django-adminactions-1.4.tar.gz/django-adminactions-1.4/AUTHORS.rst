=======
Credits
=======

Author
------

* Stefano Apostolico <s.apostolico@gmail.com>


Contributors
------------

* tdruez (`@tdruez`_)
* hanfeisun (`@hanfeisun`_)
* Narsil (`@Narsil`_)
* joelryan2k (`@joelryan2k`_)
* hekevintran (`@hekevintran`_)
* mrc75 (`@mrc75`_)
* ipmb (`@ipmb`_)
* Peter Baumgartner (`@ipmb`_)
* BoscoMW  (`@Mbosco`_)
* Bertrand Bordage  (`@BertrandBordage`_)
* jht001 (`@jht001`_)
* Cesar Abel (`@xangmuve`_)
* Viator (`@viatoriche`_)
* Serhiy Zahoriya (`@int-ua`_)
* Pavel Savchenko (`@asfaltboy`_)

.. _`@tdruez`: https://github.com/tdruez
.. _`@jht001`: https://github.com/jht001
.. _`@Narsil`: https://github.com/Narsil
.. _`@joelryan2k`: https://github.com/joelryan2k
.. _`@Mbosco`: https://github.com/Mbosco
.. _`@BertrandBordage`: https://github.com/BertrandBordage
.. _`@hekevintran`: https://github.com/hekevintran
.. _`@mrc75`: https://github.com/mrc75
.. _`@hanfeisun`: https://github.com/hanfeisun
.. _`@ipmb`: https://github.com/ipmb
.. _`@xangmuve`: https://github.com/xangmuve
.. _`@viatoriche`: https://github.com/viatoriche
.. _`@asfaltboy`: https://github.com/asfaltboy
.. _`@int-ua`: https://github.com/int-ua

