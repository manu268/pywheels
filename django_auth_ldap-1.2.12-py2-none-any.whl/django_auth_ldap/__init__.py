version = (1, 2, 12)
version_string = '.'.join(map(str, version))
