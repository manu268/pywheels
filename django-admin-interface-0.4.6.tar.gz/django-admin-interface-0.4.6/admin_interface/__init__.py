# -*- coding: utf-8 -*-

from admin_interface.version import __version__

default_app_config = 'admin_interface.apps.AdminInterfaceConfig'

