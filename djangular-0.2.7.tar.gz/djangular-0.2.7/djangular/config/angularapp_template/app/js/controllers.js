'use strict';

/* Controllers */

angular.module('{{ app_name }}.controllers', []).
    controller('MyCtrl1', [function() {

    }])
    .controller('MyCtrl2', [function() {

    }]);